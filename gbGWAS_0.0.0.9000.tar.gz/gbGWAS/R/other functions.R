#' Functions to be prepared in advance
#'
#' @param res
#' @param Z
#' @param X1
#' @param kernel
#' @param weights
#' @param pi_1
#' @param method
#' @param res.out
#' @param n.Resampling
#' @param r.corr
#'
#' @return
#' @export
#'
#' @examples
KMTest.logistic.Linear = function(res, Z, X1, kernel, weights = NULL, pi_1, method,res.out,n.Resampling,r.corr){

  # Weighted Linear Kernel
  if (kernel == "linear.weighted") {
    Z = Z * (weights)
  }

  # r.corr
  if(r.corr == 1){
    Z<-cbind(rowSums(Z))
  } else if(r.corr > 0){

    p.m<-dim(Z)[2]
    R.M<-diag(rep(1-r.corr,p.m)) + matrix(rep(r.corr,p.m*p.m),ncol=p.m)
    L<-chol(R.M,pivot=TRUE)
    Z<- Z %*% t(L)
  }

  # Get temp
  Q.Temp = t(res)%*%Z
  Q = Q.Temp %*% t(Q.Temp)/2

  Q.res = NULL
  if(n.Resampling > 0){
    Q.Temp.res = t(res.out)%*%Z
    Q.res = rowSums(rbind(Q.Temp.res^2))/2
  }



  W.1 = t(Z) %*% (Z * pi_1) - (t(Z * pi_1) %*%X1)%*%solve(t(X1)%*%(X1 * pi_1))%*% (t(X1) %*% (Z * pi_1)) # t(Z) P0 Z


  if( method == "liu" ){
    out<-Get_Liu_PVal(Q, W.1, Q.res)
  } else if( method == "liu.mod" ){
    out<-Get_Liu_PVal.MOD(Q, W.1, Q.res)
  } else if( method == "davies" ){
    out<-Get_Davies_PVal(Q, W.1, Q.res)
  } else {
    stop("Invalid Method!")
  }


  re<-list(p.value = out$p.value, p.value.resampling = out$p.value.resampling, Test.Type = method, Q = Q,  Q.resampling = Q.res, param=out$param )
  return(re)
}



# Get Beta Weights
# Z : an n x p genotype matrix with n samples and p SNPs

Beta.Weights<-function(MAF,weights.beta){

  n<-length(MAF)
  weights<-rep(0,n)
  IDX_0<-which(MAF == 0)
  if(length(IDX_0) == n){
    stop("No polymorphic SNPs")
  } else if( length(IDX_0) == 0){
    weights<-dbeta(MAF,weights.beta[1],weights.beta[2])
  } else {
    weights[-IDX_0]<-dbeta(MAF[-IDX_0],weights.beta[1],weights.beta[2])
  }


  #print(length(IDX_0))
  #print(weights[-IDX_0])
  return(weights^2)

}



#定义：主函数中嵌套的函数
mod_KMTest.linear.Linear = function(res,Z,X1,MAF,weights.beta=c(1,25),kernel="linear.weighted", weights=NULL, Sinv, res.out=NULL,n.Resampling=0,r.corr){

  #res: residuals coming from polygenic model in "SKATX" function
  #Z  : genotype matrix 基因数据 行：样本 列：SNP
  #X1 : non-SNP covariates 协变量
  #MAF: estimated MAFs
  #Sinv = SIGMAi
  #rest of the paramaters are the same as defined in SKATX


  if(length(r.corr)!=1){
    stop("Please use one value between 0 or 1 for r.corr")
  } #判断rho值格式是否正确


  n<-nrow(Z) #样本数
  # Weighted Linear Kernel
  if (kernel == "linear.weighted") {
    if(is.null(weights)){
      weights<-Beta.Weights(MAF,weights.beta)} #Beta.weight为定义函数
    Z = t(t(Z) * (weights))
  }


  if(r.corr == 1){    #burden r.corr = 1 Z变成向量
    Z<-cbind(rowSums(Z))
  } else if(r.corr > 0){
    p.m<-dim(Z)[2]
    R.M<-diag(rep(1-r.corr,p.m)) + matrix(rep(r.corr,p.m*p.m),ncol=p.m) #R_rho
    L<-chol(R.M,pivot=TRUE) #Cholesky分解
    Z<- Z %*% t(L)
  }

  # get Q
  #t()矩阵转置
  Q.Temp = t(res)%*%Sinv%*%Z   #sqrt(wj)=beta(MAF,a,b) in SKAT paper sinv = [singma]^-1
  Q = Q.Temp %*% t(Q.Temp) #Q统计量 如果是burden的话Q.Temp是数 这里是平方

  Q.res = NULL
  if(n.Resampling > 0){
    Q.Temp.res = t(res)%*%Sinv%*%Z
    Q.res = rowSums(rbind(Q.Temp.res^2))
  } #默认n.Resampling = 0 重抽样

  W.1 = 2*t(Z) %*%Sinv%*% Z - (t(Z)%*%Sinv%*% X1)%*%solve(t(X1)%*%Sinv%*% X1)%*% (t(X1) %*%Sinv%*%  Z ) # t(Z) P0 Z

  out<-Get_Davies_PVal(Q, W.1, Q.res) #内嵌函数 见下 Davies method(1980)

  #输出Davies方法的p值以及参数
  re<-list(p.value = out$p.value, Q=Q,p.value.resampling = out$p.value.resampling, Q = Q, param=out$param )
  return(re)

}


mod_KMTest.logistic.Linear = function(res, Z, X1, MAF, weights.beta = c(1,25), kernel="linear.weighted", weights = NULL, pi_1, res.out=NULL,n.Resampling=0,r.corr){


  n<-nrow(Z)
  # Weighted Linear Kernel
  if (kernel == "linear.weighted") {
    if(is.null(weights)){
      weights<-Beta.Weights(MAF,weights.beta)}
    Z = t(t(Z) * (weights))
  }


  # r.corr
  if(r.corr == 1){
    Z<-cbind(rowSums(Z))
  } else if(r.corr > 0){

    p.m<-dim(Z)[2]
    R.M<-diag(rep(1-r.corr,p.m)) + matrix(rep(r.corr,p.m*p.m),ncol=p.m)
    L<-chol(R.M,pivot=TRUE)
    Z<- Z %*% t(L)
  }

  # Get temp
  Q.Temp = t(res)%*%Z
  Q = Q.Temp %*% t(Q.Temp)/2

  Q.res = NULL
  if(n.Resampling > 0){
    Q.Temp.res = t(res.out)%*%Z
    Q.res = rowSums(rbind(Q.Temp.res^2))/2
  }

  W.1 = t(Z) %*% (Z * pi_1) - (t(Z * pi_1) %*%X1)%*%solve(t(X1)%*%(X1 * pi_1))%*% (t(X1) %*% (Z * pi_1)) # t(Z) P0 Z
  out<-Get_Davies_PVal(Q, W.1, Q.res)

  re<-list(p.value = out$p.value, Q=Q,p.value.resampling = out$p.value.resampling,  Q.resampling = Q.res, param=out$param )
  return(re)
}



SKAT_davies <- function(q,lambda,h = rep(1,length(lambda)),delta = rep(0,length(lambda)),sigma=0,lim=10000,acc=0.0001) {

  r <- length(lambda)
  if (length(h) != r) stop("lambda and h should have the same length!")
  if (length(delta) != r) stop("lambda and delta should have the same length!")

  out <- .C("qfc",lambdas=as.double(lambda),noncentral=as.double(delta),df=as.integer(h),r=as.integer(r),sigma=as.double(sigma),q=as.double(q),lim=as.integer(lim),acc=as.double(acc),trace=as.double(rep(0,7)),ifault=as.integer(0),res=as.double(0),PACKAGE="SKAT")

  out$res <- 1 - out$res

  return(list(trace=out$trace,ifault=out$ifault,Qq=out$res))

}

Get_Davies_PVal<-function(Q, W, Q.resampling = NULL){
  #W gamma服从的正态分布的协方差矩阵W 对角矩阵
  #Q  Q统计量
  K<-W/2

  Q.all<-c(Q,Q.resampling)

  re<-Get_PValue(K,Q.all)
  param<-list()
  param$liu_pval<-re$p.val.liu[1]
  param$Is_Converged<-re$is_converge[1]


  p.value.resampling = NULL
  if(length(Q.resampling) > 0){
    p.value.resampling<-re$p.value[-1]
    param$liu_pval.resampling<-re$p.val.liu[-1]
    param$Is_Converged.resampling<-re$is_converge[-1]

  } #Q.resampling <- NULL


  re<-list(p.value = re$p.value[1], param=param,p.value.resampling = p.value.resampling
           , pval.zero.msg=re$pval.zero.msg )
  return(re)
}


Get_Lambda<-function(K){

  out.s<-eigen(K,symmetric=TRUE, only.values = TRUE)
  #print(out.s$values)

  #out.s1<-eigen(K,symmetric=TRUE)
  #print(out.s1$values)

  lambda1<-out.s$values
  IDX1<-which(lambda1 >= 0)

  # eigenvalue bigger than sum(eigenvalues)/1000
  IDX2<-which(lambda1 > mean(lambda1[IDX1])/100000)
  #cat("Lambda:", lambda1, "\n")
  #K1<<-K

  if(length(IDX2) == 0){
    stop("No Eigenvalue is bigger than 0!!")
  }
  lambda<-lambda1[IDX2]
  return(lambda)

}



Get_Lambda_U_From_Z<-function(Z1){

  if(dim(Z1)[2]==1){
    Is.OnlyOne = TRUE
    lambda<-sum(Z1^2)
    U<-Z1/sqrt(lambda)
    return(list( lambda = lambda, U = cbind(U)))
  }

  #########################################
  #try1<-try(svd(Z1, LINPACK = TRUE),silent = TRUE)
  #
  #if(class(try1) == "try-error"){
  #	# try LAPACK
  #	try1<-try(svd(Z1, LINPACK = FALSE),silent = TRUE)
  #}

  try1<-try(svd(Z1),silent = TRUE)

  if(class(try1) == "try-error"){
    stop("SVD error!");
  } else {
    out.svd = try1
  }

  lambda.org<-out.svd$d^2
  IDX<-which(lambda.org > mean(lambda.org)/100000)
  if(length(IDX) <= 1){
    Is.OnlyOne = TRUE
  }

  if(length(IDX) == 0){
    return(list(lambda=NULL, U=NULL))
  }
  return(list( lambda = lambda.org[IDX], U = cbind(out.svd$u[,IDX])))
}


Get_PValue<-function(K,Q){
  #得到p值
  lambda<-Get_Lambda(K)#得到K的lambda
  re<-Get_PValue.Lambda(lambda,Q)
  return(re)
}


Get_PValue.Lambda<-function(lambda,Q){

  #print(lambda)
  n1<-length(Q)

  p.val<-rep(0,n1)
  p.val.liu<-rep(0,n1)
  is_converge<-rep(0,n1)
  p.val.liu<-Get_Liu_PVal.MOD.Lambda(Q, lambda)

  for(i in 1:n1){
    out<-SKAT_davies(Q[i],lambda,acc=10^(-6))

    p.val[i]<-out$Qq
    #p.val.liu[i]<-SKAT_liu(Q[i],lambda)

    is_converge[i]<-1

    # check convergence
    if(length(lambda) == 1){
      p.val[i]<-p.val.liu[i]
    } else if(out$ifault != 0){
      is_converge[i]<-0
    }

    # check p-value
    if(p.val[i] > 1 || p.val[i] <= 0 ){
      is_converge[i]<-0
      p.val[i]<-p.val.liu[i]
    }
  }

  p.val.msg = NULL
  p.val.log=NULL
  #cat(p.val[1])
  if(p.val[1] == 0){

    param<-Get_Liu_Params_Mod_Lambda(lambda)
    p.val.msg<-Get_Liu_PVal.MOD.Lambda.Zero(Q[1], param$muQ, param$muX, param$sigmaQ, param$sigmaX, param$l, param$d)
    p.val.log<-Get_Liu_PVal.MOD.Lambda(Q[1], lambda, log.p=TRUE)[1]

  }

  return(list(p.value=p.val, p.val.liu=p.val.liu, is_converge=is_converge, p.val.log=p.val.log, pval.zero.msg=p.val.msg))

}


Get_Liu_PVal.MOD.Lambda<-function(Q.all, lambda, log.p=FALSE){

  param<-Get_Liu_Params_Mod_Lambda(lambda)

  Q.Norm<-(Q.all - param$muQ)/param$sigmaQ
  Q.Norm1<-Q.Norm * param$sigmaX + param$muX
  p.value<- pchisq(Q.Norm1,  df = param$l,ncp=param$d, lower.tail=FALSE, log.p=log.p)

  return(p.value)

}


Get_Liu_PVal.MOD.Lambda.Zero<-function(Q, muQ, muX, sigmaQ, sigmaX, l, d){


  Q.Norm<-(Q - muQ)/sigmaQ
  Q.Norm1<-Q.Norm * sigmaX + muX

  temp<-c(0.05,10^-10, 10^-20,10^-30,10^-40,10^-50, 10^-60, 10^-70, 10^-80, 10^-90, 10^-100)
  #qchisq(temp, df=1000000000,lower.tail=FALSE)
  out<-qchisq(temp,df = l,ncp=d, lower.tail=FALSE)
  #cat(c(Q.Norm1,l,d, out))
  #cat("\n")
  IDX<-max(which(out < Q.Norm1))

  pval.msg<-sprintf("Pvalue < %e", temp[IDX])
  return(pval.msg)

}

Get_Liu_Params_Mod_Lambda<-function(lambda){
  ## Helper function for getting the parameters for the null approximation

  c1<-rep(0,4)
  for(i in 1:4){
    c1[i]<-sum(lambda^i)
  }

  muQ<-c1[1]
  sigmaQ<-sqrt(2 *c1[2])
  s1 = c1[3] / c1[2]^(3/2)
  s2 = c1[4] / c1[2]^2

  beta1<-sqrt(8)*s1
  beta2<-12*s2
  type1<-0

  #print(c(s1^2,s2))
  if(s1^2 > s2){
    a = 1/(s1 - sqrt(s1^2 - s2))
    d = s1 *a^3 - a^2
    l = a^2 - 2*d
  } else {
    type1<-1
    l = 1/s2
    a = sqrt(l)
    d = 0
  }
  muX <-l+d
  sigmaX<-sqrt(2) *a

  re<-list(l=l,d=d,muQ=muQ,muX=muX,sigmaQ=sigmaQ,sigmaX=sigmaX)
  return(re)
}




# Get polymorphic SNP
SKAT_Get_Polymorphic_SNP<-function(Z){

  temp<-apply(Z,2,var)
  ID<-which(temp == 0)
  return(ID)
}

Get_Matrix_Square.1<-function(A){

  out<-eigen(A,symmetric=TRUE)
  ID1<-which(out$values > 0)
  if(length(ID1)== 0){
    stop("Error to obtain matrix square!")
  }
  out1<-t(out$vectors[,ID1]) * sqrt(out$values[ID1])
  return(out1)
}

Get_Resampling_Bin<-function(ncase, prob, n.Resampling){

  n<-length(prob)
  err<-0
  temp<-.C("SL_Binary_Boot", as.integer(n), as.integer(n.Resampling),
           as.integer(ncase), as.double(prob), integer(n), integer(n), integer( n * n.Resampling), as.integer(err) )

  if(temp[[8]] != 1){
    return(NULL)
  }

  out<-matrix(temp[[7]],byrow=FALSE, ncol=n.Resampling)
  return(out)

}


mod_makekinship<-function (famid, id, father.id, mother.id,sex,ctype="autosome",unrelated = 0)
{
  n <- length(famid)
  if (length(id) != n)
    stop("Mismatched lengths: famid and id")
  if (length(mother.id) != n)
    stop("Mismatched lengths: famid and mother.id")
  if (length(father.id) != n)
    stop("Mismatched lengths: famid and father.id")
  if (length(sex) != n)
    stop("Mismatched lengths: sex")
  if (any(is.na(famid)))
    stop("One or more subjects with missing family id")
  if (any(is.na(id)))
    stop("One or more subjects with a missing id")
  if (is.numeric(famid)) {
    if (any(famid < 0))
      stop("Invalid family id, must be >0")
  }
  if (any(duplicated(id)))
    stop("Subject ids must be unique")
  famlist <- sort(unique(famid))
  idlist <- id
  counts <- table(famid)
  cumcount <- cumsum(counts)
  if (any(famid == unrelated)) {
    temp <- match(unrelated, names(counts))
    nzero <- counts[temp]
    counts <- counts[-temp]
    famlist <- famlist[famlist != unrelated]
    idlist[1:nzero] <- id[famid == unrelated]
    cumcount <- cumsum(counts) + nzero
  }
  else nzero <- 0
  mlist <- vector("list", length(counts))
  for (i in 1:length(counts)) {
    who <- (famid == famlist[i])
    if (sum(who) == 1)
      mlist[[i]] <- Matrix(0.5)
    else {
      mlist[[i]] <- kinship(id[who],father.id[who],mother.id[who],sex[who],chrtype=ctype)
    }
    idlist[seq(to = cumcount[i], length = counts[i])] <- id[who]
  }
  if (nzero > 0)
    mlist <- c(list(Diagonal(nzero)), mlist)
  kmat <- forceSymmetric(bdiag(mlist))
  dimnames(kmat) <- list(idlist, idlist)
  kmat
}
