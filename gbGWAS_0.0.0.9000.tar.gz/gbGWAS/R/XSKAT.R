#############加载R包######
library(SKAT)
library(lme4) #调用lmer函数计算fixef
##调用python
library(reticulate)
use_python(Sys.which("python"))
numpy <- import('numpy')
la <- numpy$linalg



#' Title
#'
#' @param Z
#' @param X
#' @param MAF
#' @param phenoI
#' @param phenoD
#' @param Om
#' @param Om_i
#' @param weights
#' @param ttype
#'
#' @return
#' @export
#'
#' @examples
XSKAT<-function(Z,X,MAF,phenoI,phenoD,Om,Om_i,weights,ttype="gaussian"){


    # W <- diag(dbeta(MAF, w[1], w[2]))#gamma服从的正态分布的协方差矩阵W 对角矩阵
    # weights <- Beta.Weights(MAF,c(1,25))
    weights <- MAF
    if (sum(MAF>=0.05)>0) weights[which(MAF>=0.05)] <- Beta.Weights(MAF[MAF>=0.05],c(0.5,0.5))
    if (sum(MAF<0.05)>0) weights[which(MAF<0.05)] <- Beta.Weights(MAF[MAF<0.05],c(1,25))

    n=nrow(X) #个体数目

    ##输出固定效应
    outI_1 <- lmer(y ~AGE+SEX+Year+(1|id), data=phenoI,control=lmerControl(check.nobs.vs.nlev = "ignore",
                                                                           check.nobs.vs.rankZ = "ignore",
                                                                           check.nobs.vs.nRE="ignore"))
    outD_1 <- lmer(y ~AGE+SEX+Year+(1|id), data=phenoD,control=lmerControl(check.nobs.vs.nlev = "ignore",
                                                                           check.nobs.vs.rankZ = "ignore",
                                                                           check.nobs.vs.nRE="ignore"))
    ## IINT
    res_I <- as.matrix(stats::rstudent(outI_1))#学生化残差
    s2_I<-as.numeric(t(res_I)%*%Om_i%*%res_I)/(n-ncol(X)) #数值，/n-3
    SIGMAi_I<-(1/s2_I)*Om_i


    ##DINT
    res_D <- as.matrix(stats::rstudent(outD_1))#学生化残差
    s2_D<-as.numeric(t(res_D)%*%Om_i%*%res_D)/(n-ncol(X)) #数值，/n-3
    SIGMAi_D<-(1/s2_D)*Om_i


  p0 = mod_KMTest.linear.Linear(res_I,Z,X,MAF,weights.beta=NULL,kernel="linear.weighted", weights,SIGMAi_I, res.out=NULL,n.Resampling=0,r.corr = 0)$p.value #SKAT
  p1 = mod_KMTest.linear.Linear(res_I,Z,X,MAF,weights.beta=NULL,kernel="linear.weighted", weights,SIGMAi_I, res.out=NULL,n.Resampling=0,r.corr = 1)$p.value #BURDEN
  p2 = mod_KMTest.linear.Linear(res_D,Z,X,MAF,weights.beta=NULL,kernel="linear.weighted", weights,SIGMAi_D, res.out=NULL,n.Resampling=0,r.corr = 0)$p.value #SKAT
  p3 = mod_KMTest.linear.Linear(res_D,Z,X,MAF,weights.beta=NULL,kernel="linear.weighted", weights,SIGMAi_D, res.out=NULL,n.Resampling=0,r.corr = 1)$p.value #BURDEN

  #cauchy合并
  p4<-1/2-(atan(1/2*(tan((0.5-p0)*pi)+tan((0.5-p2)*pi))))/pi
  p5<-1/2-(atan(1/2*(tan((0.5-p1)*pi)+tan((0.5-p3)*pi))))/pi

  # p <- data.frame('SKAT_IINT'=p0,'BURDEN_IINT'=p1,'SKAT_DINT'=p2,'BURDEN_DINT'=p3,"Combined_SKAT"=p4,"Combined_Burden"=p5)
  p <- data.frame('BURDEN_DINT'=p3,'SKAT_DINT'=p2,'BURDEN_IINT'=p1,'SKAT_IINT'=p0,"Combined_Burden"=p5,"Combined_SKAT"=p4)
}
